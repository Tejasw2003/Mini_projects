# result_system.py
"""
ResultSystem class to manage all students.

Responsibilities:
- Add students
- Add subject marks
- Generate student reports
- List all students

💡 Hint:
- Store students in dict {student_id: Student}
- Use exceptions for invalid student IDs
"""

from student import Student
from exceptions import StudentNotFoundError, StudentIDAlreadyExistsError, DuplicateSubjectError

class ResultSystem:
    def __init__(self):
        # self.students = {}
        self.students = {}

    def add_student(self, student):
        # Hint: self.students[student.student_id] = student
        if student.student_id in self.students:
            raise StudentIDAlreadyExistsError(f"Student with ID '{student.student_id}' already exists.")
        self.students[student.student_id] = student

    def add_subject_marks(self, student_id, subject_name, marks):
        # Hint: find student and call student.add_subject()
        if student_id not in self.students:
            raise StudentNotFoundError(f"Student with ID '{student_id}' not found.")
        try:
            self.students[student_id].add_subject(subject_name, marks)
        except DuplicateSubjectError as e:
            raise e

    def generate_student_report(self, student_id):
        # Hint: call student.generate_report()
        if student_id not in self.students:
            raise StudentNotFoundError(f"Student with ID '{student_id}' not found.")
        self.students[student_id].generate_report()

    def list_all_students(self):
        # Hint: Loop through students and print summary
        if not self.students:
            print("No students registered yet.")
            return
        print("List of all students:")
        for student in self.students.values():
            print(str(student))
