# subject.py
"""
Subject class to store subject name and marks.

Attributes:
- name (str)
- marks (int)

💡 Hint:
- Marks should be between 0–100.
"""

class Subject:
    def __init__(self, name, marks):
        self.name = name
        if not (0 <= marks <= 100):
            raise ValueError(f"Marks must be between 0 and 100. Got {marks}.")
        self.marks = marks
    def __str__(self):
        return f"{self.name}: {self.marks}"