# exceptions.py
"""
Custom exceptions for Student Result Management.
"""

# exceptions.py
"""
Custom exceptions for Student Result Management.
"""

class StudentNotFoundError(Exception):
    """
    Raised when a student with the given ID is not found.
    """
    pass
class DuplicateSubjectError(Exception):
    """
    Raised when trying to add a subject that already exists for the student.
    """
    pass
class StudentIDAlreadyExistsError(Exception):
    """
    Raised when trying to add a student with an ID that already exists.
    """
    pass