# utils.py
"""
Utility functions for calculations.

Functions:
- get_grade(average) → returns grade (A, B, C, Fail)
"""

def get_grade(average):
    """
    💡 Hint:
    - A: 90–100
    - B: 75–89
    - C: 50–74
    - Fail: < 50
    """
    if 90 <= average <= 100:
        return 'A'
    elif 75 <= average < 90:
        return 'B'
    elif 50 <= average < 75:
        return 'C'
    else:
        return 'Fail'