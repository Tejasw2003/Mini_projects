# student.py
"""
Student class to manage subjects and marks.

Attributes:
- student_id (str)
- name (str)
- subjects (dict → {subject_name: Subject})

Methods:
- add_subject(name, marks)
- calculate_average()
- generate_report()

💡 Hint:
- Use Subject class for each subject.
- calculate_average → sum of marks / number of subjects.
"""

from subject import Subject
from utils import get_grade

class Student:
    def __init__(self, student_id, name):
        self.student_id = student_id
        self.name = name
        self.subjects = {}

    def add_subject(self, subject_name, marks):
        # Hint: Create a Subject object and store in self.subjects
        subject = Subject(subject_name, marks)
        self.subjects[subject_name] = subject

    def calculate_average(self):
        # Hint: Use sum() over self.subjects.values()
        if not self.subjects:
            return 0
        total_marks = sum(subject.marks for subject in self.subjects.values())
        num_subjects = len(self.subjects)
        return total_marks / num_subjects

    def generate_report(self):
        # Hint: Print all subjects, total, average, and grade (utils.get_grade)
        print(f"Student Report for {self.name} (ID: {self.student_id})")
        if not self.subjects:
            print("No subjects added yet.")
            return
        for subject_name, subject in self.subjects.items():
            print(f"{subject_name}: {subject.marks}")
        total = sum(subject.marks for subject in self.subjects.values())
        average = self.calculate_average()
        grade = get_grade(average)
        print(f"Total Marks: {total}")
        print(f"Average: {average:.2f}")
        print(f"Grade: {grade}")

    def __str__(self):
        # Hint: return student_id + name + total subjects
        return f"{self.student_id} - {self.name} ({len(self.subjects)} subjects)"