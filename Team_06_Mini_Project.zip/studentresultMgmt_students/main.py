# main.py
"""
Main entry point for Student Result Management System.

Steps:
1. Import ResultSystem from result_system.py
2. Create a ResultSystem instance.
3. Provide a menu:
   - Add Student
   - Add Subject Marks
   - View Student Report
   - View All Students
   - Exit
4. Use input() to interact with users.

💡 Hint:
- Wrap risky input operations in try/except.
- Convert marks to int before storing.
"""

# main.py
"""
Main entry point for Student Result Management System.

Steps:
1. Import ResultSystem from result_system.py
2. Create a ResultSystem instance.
3. Provide a menu:
   - Add Student
   - Add Subject Marks
   - View Student Report
   - View All Students
   - Exit
4. Use input() to interact with users.

💡 Hint:
- Wrap risky input operations in try/except.
- Convert marks to int before storing.
"""

from result_system import ResultSystem
from student import Student
from exceptions import StudentNotFoundError, StudentIDAlreadyExistsError, DuplicateSubjectError

def main():
    # result_system = ResultSystem()

    # while True:
    #     print("\n--- Student Result Management ---")
    #     print("1. Add Student")
    #     print("2. Add Subject Marks")
    #     print("3. View Student Report")
    #     print("4. View All Students")
    #     print("5. Exit")
    #
    #     choice = input("Enter choice: ")
    #
    #     if choice == "1":
    #         # Call add_student()
    #         pass
    #     elif choice == "2":
    #         # Call add_subject_marks()
    #         pass
    #     elif choice == "3":
    #         # Call generate_report()
    #         pass
    #     elif choice == "4":
    #         # Print summary of all students
    #         pass
    #     elif choice == "5":
    #         break
    #     else:
    #         print("Invalid choice.")
    result_system = ResultSystem()

    while True:
        print("\n--- Student Result Management ---")
        print("1. Add Student")
        print("2. Add Subject Marks")
        print("3. View Student Report")
        print("4. View All Students")
        print("5. Exit")

        choice = input("Enter choice: ").strip()

        if choice == "1":
            try:
                student_id = input("Enter student ID: ").strip()
                if not student_id:
                    print("Student ID cannot be empty.")
                    continue
                name = input("Enter student name: ").strip()
                if not name:
                    print("Student name cannot be empty.")
                    continue
                student = Student(student_id, name)
                result_system.add_student(student)
                print("Student added successfully.")
            except StudentIDAlreadyExistsError as e:
                print(f"Error: {e}")
            except Exception as e:
                print(f"An error occurred: {e}")
        elif choice == "2":
            try:
                student_id = input("Enter student ID: ").strip()
                if not student_id:
                    print("Student ID cannot be empty.")
                    continue
                subject_name = input("Enter subject name: ").strip()
                if not subject_name:
                    print("Subject name cannot be empty.")
                    continue
                marks_input = input("Enter marks (0-100): ").strip()
                marks = int(marks_input)
                result_system.add_subject_marks(student_id, subject_name, marks)
                print("Subject marks added successfully.")
            except ValueError:
                print("Invalid marks. Please enter a valid integer between 0 and 100.")
            except StudentNotFoundError as e:
                print(f"Error: {e}")
            except DuplicateSubjectError as e:
                print(f"Error: {e}")
            except Exception as e:
                print(f"An error occurred: {e}")
        elif choice == "3":
            try:
                student_id = input("Enter student ID: ").strip()
                if not student_id:
                    print("Student ID cannot be empty.")
                    continue
                result_system.generate_student_report(student_id)
            except StudentNotFoundError as e:
                print(f"Error: {e}")
            except Exception as e:
                print(f"An error occurred: {e}")
        elif choice == "4":
            result_system.list_all_students()
        elif choice == "5":
            print("Exiting the system. Goodbye!")
            break
        else:
            print("Invalid choice. Please try again.")

if __name__ == "__main__":
    main()