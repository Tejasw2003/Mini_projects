# report.py
"""
Reporting functions for Student Results.

Functions:
- student_report(student)
- all_students_report(result_system)

💡 Hint:
- student_report → print subjects, marks, total, average, grade
- all_students_report → print summary for each student
"""

def student_report(student):
    # Hint: use student.generate_report()
    student.generate_report()

def all_students_report(result_system):
    # Hint: loop through result_system.students
    if not result_system.students:
        print("No students registered yet.")
        return
    print("Full Reports for All Students:")
    print("-" * 50)
    for student_id, student in result_system.students.items():
        print(f"\nReport for Student ID: {student_id}")
        student_report(student)
        print("-" * 50)